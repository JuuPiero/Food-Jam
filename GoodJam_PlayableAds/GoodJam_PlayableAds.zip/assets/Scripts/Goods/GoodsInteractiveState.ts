import { Color } from 'cc';
import { GoodsState } from './GoodsState';

export class GoodsInteractiveState extends GoodsState {
    
    public enterState(): void {
        this._goods.node.active = true;
        this._goods.sptGoods.color = new Color(100, 100, 100, 255);
    }

    public exitState(): void {
        this._goods.node.active = true;
    }
}


