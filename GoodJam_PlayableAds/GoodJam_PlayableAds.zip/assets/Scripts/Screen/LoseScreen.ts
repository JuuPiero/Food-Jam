import { _decorator, Component, Node } from 'cc';
import { ScreenBase } from './ScreenBase';
const { ccclass, property } = _decorator;

@ccclass('LoseScreen')
export class LoseScreen extends ScreenBase {
    
    
}


