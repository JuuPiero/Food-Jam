import { _decorator, Component, instantiate, Node, NodePool, Prefab } from 'cc';
import { Box } from '../Box/Box';
import { ILevelData } from '../Data/ILevelData';
import { ObjectPool } from '../Modules/ObjectPool';
import { SlotManager } from '../Slot/SlotManager';
const { ccclass, property } = _decorator;

@ccclass('BoxManager')
export class BoxManager extends Component {
    
    @property(SlotManager)
    slotManager: SlotManager = null;

    @property(Prefab)
    prefabBox: Prefab = null;

    @property([Node])
    nodePositions: Node[] = [];
    
    private _pool = new NodePool();
    private _boxesActive: Box[] = [];
    private _boxes: Box[] = [];

    public initialize(data: ILevelData): void {
        this.initPool();
        let ids = this.getAllID(data);


    }

    public put(box: Box): void {
        this._pool.put(box.node);
    }

    public get(): Box {
        
    }

    public fill(): void {
        for (let i = 0; i < this.nodePositions.length; i++) {
            let node = this.nodePositions[i];
            if (node.children.length > 0) {

            }
        }
    }

    private initPool(): void {
        for (let i = 0; i < 5; i++) {
            let node = instantiate(this.prefabBox);
            this._pool.put(node);
        }
    }

    private getAllID(data: ILevelData): number[] {
        // Lấy data của tất cả layer
        let layersData = [];
        for (let i = 0; i < data.cells.length; i++) {
            let shelf = data.cells[i];
            layersData.push(shelf.itemsLayer);
        }
        let ids = [];
        for (let i = 0; i < layersData.length; i++) {
            let layer = layersData[i];
            if (layer.length > 0) {
                ids = ids.concat(layer.shift());
            }
        }
    }

    private checkFullSlot(): boolean {
        let result = false;
        this.slotManager.freeSlots.forEach(slot => {
            if (slot)
                result = slot.isFull();
        });
        return result;
    }

    private match():  {

    }
}


