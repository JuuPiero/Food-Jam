import { _decorator, Animation, Component, Label, Node, Prefab, Sprite, SpriteFrame } from 'cc';
import { IBox } from '../Base/Interfaces/IBox';
import { LevelLoader } from '../Core/LevelLoader';
const { ccclass, property } = _decorator;

export enum EBoxAnimation {
    IDLE = "",
    COMPLETE = ""
}

@ccclass('Box')
export class Box extends Component implements IBox {

    @property(Animation)
    readonly animBox: Animation = null;

    @property(Prefab)
    prefabSlot: Prefab = null;

    @property(Node)
    nodeSlots: Node = null;

    public levelLoader: LevelLoader = null;

    protected _boxId: number = -1;
    protected _total: number = 0;

    public initialize(id: number, count: number): void {
        this._boxId = id;
        this._total = count;
    }

    public reset(): void {
        this.animBox.play(EBoxAnimation.IDLE);
    }

    public complete(): void {
        this.animBox.play(EBoxAnimation.COMPLETE);
    }


}


