import { _decorator, Component, Node } from 'cc';
import { FreeSlot } from './FreeSlot';
const { ccclass, property } = _decorator;

@ccclass('SlotManager')
export class SlotManager extends Component {
    
    @property([FreeSlot])
    freeSlots: FreeSlot[] = [];

    public initialize(): void {

    }

    public reset(): void {
        this.freeSlots.forEach(slot => {
            if (slot)
                slot.reset();
        });
    }
}


